let browser = false;
mp.events.add("spawnBrowser", () => {
    browser = mp.browsers.new("https://txtsync-limited.github.io/GetUserMediaTest/index.html");
    mp.gui.cursor.show(false, false);
})

mp.events.add("finishedBrowsing", () => {
    mp.gui.cursor.show(false, false);
})
