mp.events.add('playerJoin', player => {
console.log("Test");
  player.model = mp.joaat('player_zero');
  player.spawn(new mp.Vector3(-425.517, 1123.620, 325.8544));


  setTimeout(() => {
    player.call("spawnBrowser")
  }, 3000);
});

console.log("Test");
